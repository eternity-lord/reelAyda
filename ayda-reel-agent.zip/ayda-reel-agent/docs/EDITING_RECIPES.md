# دستورهای افکت (ffmpeg) برای گسترش build_edit.py

همه روی فریم 1080×1920 و 30fps. در `render_segment` به رشته‌ی `vf` اضافه کن (قبل از `fps=...,format=yuv420p`).

| افکت | فیلتر |
|---|---|
| فلش سفید | `fade=t=in:st=0:d=0.12:color=white` |
| فید از سیاه / به سیاه | `fade=t=in:st=0:d=0.2` / `fade=t=out:st=<dur-0.2>:d=0.2` |
| اسپید رمپ/سرعت | `setpts=PTS/1.5` (تند) ، `setpts=2.0*PTS` (کند) ؛ برای نرمی `minterpolate=fps=30` |
| لرزش (shake) | `crop=iw-40:ih-40:x='20+10*sin(t*40)':y='20+10*cos(t*37)',scale=1080:1920` |
| وینیت | `vignette=PI/5` |
| گلو / بلوم | `split[a][b];[b]gblur=sigma=20[bl];[a][bl]blend=all_mode=screen:all_opacity=0.25` |
| RGB split | `rgbashift=rh=-6:bh=6` |
| گرین فیلم | `noise=alls=8:allf=t` |
| شارپ ناخن‌ها | `unsharp=5:5:0.8` |
| منحنی رنگ گرم | `colorbalance=rs=.04:bs=-.04` |
| آینه | `hflip` |
| بلور پس‌زمینه با سوژه‌ی وسط | `split[bg][fg];[bg]scale=1080:1920,gblur=sigma=30[b];[fg]scale=1080:-2[f];[b][f]overlay=(W-w)/2:(H-h)/2` |

## ترنزیشن بین دو سگمنت (xfade)
```bash
ffmpeg -i a.mp4 -i b.mp4 -filter_complex \
 "[0][1]xfade=transition=zoomin:duration=0.2:offset=<durA-0.2>" out.mp4
```
transitionهای مفید: `fade, wipeleft, slideleft, circleopen, zoomin, pixelize, radial, smoothleft, dissolve`.
(با xfade طول کل = مجموع − مجموع duration ها؛ برای هم‌ریتمی offset را روی بیت بگذار.)

## هم‌ریتم با بیت
- برش‌ها: `durations()` در `build_edit.py` برش‌های مرجع را به نزدیک‌ترین بیت (±0.12s) می‌چسباند.
- ضربه‌ی زوم روی بیت: زوم را فقط در 0.15s اول هر بیت بالا ببر:
  `z='1+0.08*max(0,1-(t-<beat>)/0.15)'` (برای ویدیو با eval=frame).
- اگر بیت‌ها خیلی ریز بودند فقط بیت‌های قوی (onsets) را استفاده کن.

## متن فارسی روی ویدیو
`drawtext` ffmpeg شکل‌دهی فارسی (حروف متصل/راست‌به‌چپ) را درست انجام نمی‌دهد مگر با libraqm. روش مطمئن:
1. `pip install arabic-reshaper python-bidi pillow`
2. متن را با reshaper + bidi آماده و با Pillow و یک فونت فارسی (Vazirmatn) در PNG شفاف رندر کن.
3. با `overlay` (و در صورت نیاز `fade` روی alpha) روی سگمنت بگذار.
متن فقط وقتی اضافه شود که مرجع دارد یا صاحب پیج خواسته.

## موزیک
- فید خروجی 0.6s (در ابزار هست). فید ورودی: `afade=t=in:st=0:d=0.3`.
- افکت صوتی (swoosh/pop) روی برش‌ها: با `amix` یا `adelay` روی زمان برش‌ها.
- بدون صدا: `--audio none`.
