#!/usr/bin/env bash
set -euo pipefail
command -v ffmpeg >/dev/null || { echo "ffmpeg نصب نیست (brew/apt install ffmpeg)"; exit 1; }
command -v git-lfs >/dev/null || echo "هشدار: git-lfs نصب نیست؛ فایل‌های حجیم مشکل می‌خورند"
python3 -m venv .venv
. .venv/bin/activate
pip install -r requirements.txt
git lfs install || true
echo "OK"
