#!/usr/bin/env bash
# استفاده: scripts/publish.sh <post-name> ["پیام کامیت"]
set -euo pipefail
POST="${1:?usage: scripts/publish.sh <post-name> [message]}"
MSG="${2:-feat(reel): add $POST}"
[ -f "outputs/$POST.mp4" ] || { echo "outputs/$POST.mp4 پیدا نشد"; exit 1; }
git pull --rebase --autostash || true
git add outputs/"$POST".*
git commit -m "$MSG" || echo "چیزی برای کامیت نبود"
git push origin HEAD
