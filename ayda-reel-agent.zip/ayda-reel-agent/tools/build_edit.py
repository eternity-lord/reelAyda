#!/usr/bin/env python3
"""ساخت ریلز از مدیای من بر اساس پروفایل مرجع.

  python tools/build_edit.py --profile profiles/ref-01/profile.json \
      --inputs inputs/post-01 --out outputs/post-01.mp4 [--audio ref|none|path]
"""
import argparse
import json
import re
import shutil
import tempfile
from pathlib import Path

import cv2
import numpy as np
import yaml

from common import sh, probe, frame_at, color_stats

W, H, FPS = 1080, 1920, 30
IMG = {".jpg", ".jpeg", ".png", ".webp"}
VID = {".mp4", ".mov", ".m4v"}
ENC = ["-c:v", "libx264", "-preset", "fast", "-crf", "18", "-r", str(FPS), "-pix_fmt", "yuv420p", "-an"]
NEUTRAL = {"saturation": 100.0, "brightness": 128.0, "contrast": 50.0, "warmth": 0.0}


def clamp(v, lo, hi):
    return max(lo, min(hi, v))


def natural(p):
    return [int(t) if t.isdigit() else t.lower() for t in re.split(r"(\d+)", p.name)]


def load_media(inp, manifest, tmp):
    files = [p for p in sorted(inp.iterdir(), key=natural) if p.suffix.lower() in IMG | VID]
    skip = set(manifest.get("skip") or [])
    files = [p for p in files if p.name not in skip]
    if manifest.get("order"):
        by = {p.name: p for p in files}
        files = [by[n] for n in manifest["order"] if n in by]
    clips = manifest.get("clips") or {}
    media = []
    for p in files:
        opt = clips.get(p.name) or {}
        if p.suffix.lower() in IMG:
            img = cv2.imread(str(p))  # EXIF orientation اعمال می‌شود
            if img is None:
                print(f"skip (unreadable): {p}")
                continue
            q = tmp / f"{p.stem}.jpg"
            cv2.imwrite(str(q), img, [cv2.IMWRITE_JPEG_QUALITY, 95])
            media.append({"name": p.name, "kind": "image", "path": q, "stats": color_stats([img]), "opt": opt})
        else:
            info = probe(p)
            f = frame_at(cv2.VideoCapture(str(p)), info["duration"] / 2)
            media.append({"name": p.name, "kind": "video", "path": p, "dur": info["duration"],
                          "stats": color_stats([f]) if f is not None else NEUTRAL, "opt": opt})
    if not media:
        raise SystemExit("no media found in inputs")
    return media


def durations(profile, snap, tol=0.12):
    scenes = profile["scenes"]
    beats = np.array((profile.get("audio") or {}).get("beats") or [])
    bounds = [0.0]
    for s in scenes[:-1]:
        c = s["end"]
        if snap and len(beats):
            b = float(beats[np.abs(beats - c).argmin()])
            if abs(b - c) <= tol:
                c = b
        bounds.append(c)
    bounds.append(profile["duration"])
    return [max(bounds[i + 1] - bounds[i], 0.25) for i in range(len(bounds) - 1)]


def zoom_params(motion, intensity):
    sc, dx, dy, label = motion["scale"], motion["dx"], motion["dy"], motion["label"]
    if label == "zoom_in":
        z0, z1 = 1.0, clamp(1 + (sc - 1) * intensity, 1.04, 1.4)
    elif label == "zoom_out":
        z0, z1 = clamp(1 + (1 / sc - 1) * intensity, 1.04, 1.4), 1.0
    else:
        z0, z1 = 1.0, 1.0 + 0.06 * intensity  # پانچ ملایم تا ثابت نماند
    sx = clamp(-dx * intensity, -0.06, 0.06) if label == "pan" else 0.0
    sy = clamp(-dy * intensity, -0.06, 0.06) if label == "pan" else 0.0
    return z0, z1, sx, sy


def grade(ms, ref, strength):
    mix = lambda v: 1 + (v - 1) * strength
    sat = mix(clamp(ref["saturation"] / max(ms["saturation"], 1), 0.8, 1.35))
    con = mix(clamp(ref["contrast"] / max(ms["contrast"], 1), 0.9, 1.25))
    br = clamp((ref["brightness"] - ms["brightness"]) / 255 * 0.6, -0.08, 0.08) * strength
    return f"eq=saturation={sat:.3f}:contrast={con:.3f}:brightness={br:.3f}"


def render_segment(m, scene, dur, start, intensity, ref_color, strength, out):
    z0, z1, sx, sy = zoom_params(scene["motion"], intensity)
    frames = max(2, int(round(dur * FPS)))
    if m["kind"] == "image":
        ze = f"{z0}+({z1}-{z0})*on/{frames}"
        xe = f"(iw-iw/zoom)/2+({sx})*iw*on/{frames}"
        ye = f"(ih-ih/zoom)/2+({sy})*ih*on/{frames}"
        vf = (f"scale=2160:3840:force_original_aspect_ratio=increase,crop=2160:3840,"
              f"zoompan=z='{ze}':x='{xe}':y='{ye}':d={frames}:s={W}x{H}:fps={FPS}")
        pre = ["-i", m["path"], "-frames:v", frames]
    else:
        ze = f"({z0}+({z1}-{z0})*t/{dur:.3f})"
        vf = (f"scale={W}:{H}:force_original_aspect_ratio=increase,crop={W}:{H},"
              f"scale=w='trunc({W}*{ze}/2)*2':h='trunc({H}*{ze}/2)*2':eval=frame,"
              f"crop={W}:{H}:x='(iw-{W})/2+({sx})*{W}*t/{dur:.3f}':y='(ih-{H})/2+({sy})*{H}*t/{dur:.3f}'")
        pre = ["-stream_loop", "-1", "-ss", f"{start:.3f}", "-t", f"{dur:.3f}", "-i", m["path"]]
    vf += "," + grade(m["stats"], ref_color, strength)
    tr = scene.get("transition_in", "cut")
    if tr == "flash":
        vf += ",fade=t=in:st=0:d=0.12:color=white"
    elif tr == "fade":
        vf += ",fade=t=in:st=0:d=0.2"
    vf += f",fps={FPS},format=yuv420p,setsar=1"
    sh(["ffmpeg", "-y", *pre, "-vf", vf, "-t", f"{dur:.3f}", *ENC, out])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--profile", required=True)
    ap.add_argument("--inputs", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--audio", default=None, help="ref | none | path")
    ap.add_argument("--no-snap", action="store_true")
    ap.add_argument("--intensity", type=float, default=None)
    ap.add_argument("--grade-strength", type=float, default=0.7)
    ap.add_argument("--keep-tmp", action="store_true")
    a = ap.parse_args()

    pfile = Path(a.profile)
    profile = json.loads(pfile.read_text())
    inp, out = Path(a.inputs), Path(a.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    mf = inp / "manifest.yaml"
    manifest = (yaml.safe_load(mf.read_text()) or {}) if mf.exists() else {}
    intensity = a.intensity if a.intensity is not None else float(manifest.get("intensity", 1.0))
    audio_mode = a.audio or manifest.get("audio", "ref")

    tmp = Path(tempfile.mkdtemp(prefix="reel_"))
    try:
        media = load_media(inp, manifest, tmp)
        durs = durations(profile, not a.no_snap)
        scenes = profile["scenes"]
        n = max(len(media), len(scenes))
        used, plan, segs = {}, [], []
        for k in range(n):
            m, sc, d = media[k % len(media)], scenes[k % len(scenes)], durs[k % len(durs)]
            u = used.get(m["name"], 0)
            used[m["name"]] = u + 1
            start = float(m["opt"].get("start", 0.0))
            if m["kind"] == "video":
                start += u * d
                if m["dur"] > d:
                    start = start % max(m["dur"] - d, 0.01)
            seg = tmp / f"seg_{k:03d}.mp4"
            print(f"[{k + 1}/{n}] {m['name']} {d:.2f}s {sc['motion']['label']} {sc.get('transition_in')}")
            render_segment(m, sc, d, start, intensity, profile["color"], a.grade_strength, seg)
            segs.append(seg)
            plan.append({"segment": k, "media": m["name"], "duration": round(d, 3), "start": round(start, 3),
                         "motion": sc["motion"]["label"], "transition_in": sc.get("transition_in")})

        lst = tmp / "list.txt"
        lst.write_text("".join(f"file '{s}'\n" for s in segs))
        joined = tmp / "joined.mp4"
        sh(["ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", lst, "-c", "copy", joined])
        total = sum(p["duration"] for p in plan)

        audio = None
        if audio_mode == "ref" and profile.get("audio"):
            audio = pfile.parent / profile["audio"]["file"]
        elif audio_mode not in ("ref", "none") and Path(audio_mode).exists():
            audio = Path(audio_mode)

        cmd = ["ffmpeg", "-y", "-i", joined]
        if audio:
            cmd += ["-stream_loop", "-1", "-i", audio, "-map", "0:v", "-map", "1:a",
                    "-af", f"afade=t=out:st={max(total - 0.6, 0):.2f}:d=0.6",
                    "-c:a", "aac", "-b:a", "192k", "-t", f"{total:.3f}"]
        cmd += ["-c:v", "copy", "-movflags", "+faststart", out]
        sh(cmd)
        out.with_suffix(".plan.json").write_text(json.dumps(
            {"profile": profile["name"], "audio": str(audio) if audio else None,
             "total": round(total, 2), "segments": plan}, ensure_ascii=False, indent=2))
        print(f"done -> {out} ({total:.1f}s)")
    finally:
        if not a.keep_tmp:
            shutil.rmtree(tmp, ignore_errors=True)


if __name__ == "__main__":
    main()
