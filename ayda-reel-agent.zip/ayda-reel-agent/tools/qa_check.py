#!/usr/bin/env python3
"""کنترل کیفیت خروجی + ساخت contact sheet برای بازبینی چشمی.
  python tools/qa_check.py outputs/post-01.mp4
"""
import json
import re
import subprocess
import sys
from pathlib import Path

from common import probe, sh


def main():
    v = Path(sys.argv[1])
    info = probe(v)
    problems = []
    if (info["width"], info["height"]) != (1080, 1920):
        problems.append(f"resolution {info['width']}x{info['height']} (باید 1080x1920)")
    if abs(info["fps"] - 30) > 1:
        problems.append(f"fps {info['fps']:.1f}")
    if info["duration"] > 90:
        problems.append("طول بیشتر از 90 ثانیه")
    if info["duration"] < 3:
        problems.append("طول خیلی کوتاه")
    warnings = [] if info["has_audio"] else ["بدون صدا"]

    r = subprocess.run(["ffmpeg", "-i", str(v), "-vf", "blackdetect=d=0.3:pix_th=0.08", "-an", "-f", "null", "-"],
                       capture_output=True, text=True)
    blacks = re.findall(r"black_start:([\d.]+) black_end:([\d.]+)", r.stderr)
    if blacks:
        problems.append(f"فریم سیاه: {blacks}")

    sheet = v.with_suffix(".contact.jpg")
    sh(["ffmpeg", "-y", "-i", v, "-vf", "fps=1.5,scale=216:384,tile=8x3", "-frames:v", "1", sheet])
    rep = {"file": str(v), **info, "problems": problems, "warnings": warnings, "contact_sheet": str(sheet)}
    print(json.dumps(rep, ensure_ascii=False, indent=2))
    sys.exit(1 if problems else 0)


if __name__ == "__main__":
    main()
