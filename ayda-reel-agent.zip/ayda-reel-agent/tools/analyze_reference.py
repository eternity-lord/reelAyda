#!/usr/bin/env python3
"""تحلیل فیلم مرجع -> profiles/<name>/{profile.json, audio.m4a, frames/}

استفاده:
  python tools/analyze_reference.py references/ref-01.mp4 [--name ref-01] [--threshold 27]
"""
import argparse
import json
import math
import tempfile
from pathlib import Path

import cv2
import numpy as np

from common import sh, probe, frame_at, small, color_stats

STATIC = {"label": "static", "scale": 1.0, "dx": 0.0, "dy": 0.0}


def detect_scenes(video, duration, threshold):
    from scenedetect import detect, ContentDetector
    scenes = detect(str(video), ContentDetector(threshold=threshold, min_scene_len=6))
    if not scenes:
        return [(0.0, duration)]
    out = [(s.get_seconds(), e.get_seconds()) for s, e in scenes]
    out[-1] = (out[-1][0], duration)
    return out


def estimate_motion(cap, start, end):
    """scale>1 یعنی زوم‌این؛ dx,dy جابجایی نرمال‌شده‌ی محتوا"""
    ln = end - start
    a = frame_at(cap, start + 0.1 * ln)
    b = frame_at(cap, end - 0.1 * ln)
    if a is None or b is None:
        return dict(STATIC)
    a, b = small(a), small(b)
    h, w = a.shape[:2]
    orb = cv2.ORB_create(1500)
    ka, da = orb.detectAndCompute(cv2.cvtColor(a, cv2.COLOR_BGR2GRAY), None)
    kb, db = orb.detectAndCompute(cv2.cvtColor(b, cv2.COLOR_BGR2GRAY), None)
    if da is None or db is None:
        return dict(STATIC)
    matches = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=True).match(da, db)
    if len(matches) < 12:
        return dict(STATIC)
    pa = np.float32([ka[m.queryIdx].pt for m in matches])
    pb = np.float32([kb[m.trainIdx].pt for m in matches])
    M, _ = cv2.estimateAffinePartial2D(pa, pb, method=cv2.RANSAC)
    if M is None:
        return dict(STATIC)
    scale = min(max(float(math.hypot(M[0, 0], M[1, 0])), 0.7), 1.6)
    dx, dy = float(M[0, 2] / w), float(M[1, 2] / h)
    if scale > 1.06:
        label = "zoom_in"
    elif scale < 0.94:
        label = "zoom_out"
    elif abs(dx) > 0.05 or abs(dy) > 0.05:
        label = "pan"
    else:
        label = "static"
    return {"label": label, "scale": round(scale, 3), "dx": round(dx, 3), "dy": round(dy, 3)}


def transition_in(cap, start, end, fps):
    mid = frame_at(cap, (start + end) / 2)
    first = frame_at(cap, start + 1.5 / fps)
    if mid is None or first is None:
        return "cut"
    g = lambda f: float(cv2.cvtColor(small(f, 160), cv2.COLOR_BGR2GRAY).mean())
    d = g(first) - g(mid)
    if d > 18:
        return "flash"
    if d < -35:
        return "fade"
    return "cut"


def analyze_audio(video, outdir, cuts):
    import librosa
    sh(["ffmpeg", "-y", "-i", video, "-vn", "-c:a", "aac", "-b:a", "192k", outdir / "audio.m4a"])
    with tempfile.TemporaryDirectory() as td:
        wav = Path(td) / "a.wav"
        sh(["ffmpeg", "-y", "-i", video, "-vn", "-ac", "1", "-ar", "22050", wav])
        y, sr = librosa.load(str(wav), sr=22050)
    tempo, bf = librosa.beat.beat_track(y=y, sr=sr, units="frames")
    beats = librosa.frames_to_time(bf, sr=sr)
    onsets = librosa.onset.onset_detect(y=y, sr=sr, units="time")
    ratio = 0.0
    if len(beats) and cuts:
        ratio = float(np.mean([np.min(np.abs(beats - c)) <= 0.12 for c in cuts]))
    return {
        "file": "audio.m4a", "bpm": round(float(np.atleast_1d(tempo)[0]), 1),
        "beats": [round(float(b), 3) for b in beats],
        "onsets": [round(float(o), 3) for o in onsets],
        "cuts_on_beat_ratio": round(ratio, 2),
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("video")
    ap.add_argument("--name")
    ap.add_argument("--threshold", type=float, default=27.0)
    a = ap.parse_args()

    video = Path(a.video)
    name = a.name or video.stem
    outdir = Path("profiles") / name
    (outdir / "frames").mkdir(parents=True, exist_ok=True)

    info = probe(video)
    scenes = detect_scenes(video, info["duration"], a.threshold)
    cap = cv2.VideoCapture(str(video))

    sc_out, sample = [], []
    for i, (s, e) in enumerate(scenes):
        mid = frame_at(cap, (s + e) / 2)
        if mid is not None:
            cv2.imwrite(str(outdir / "frames" / f"scene_{i:02d}.jpg"), small(mid, 540))
            sample.append(mid)
        sc_out.append({
            "index": i, "start": round(s, 3), "end": round(e, 3), "duration": round(e - s, 3),
            "motion": estimate_motion(cap, s, e),
            "transition_in": "cut" if i == 0 else transition_in(cap, s, e, info["fps"]),
            "frame": f"frames/scene_{i:02d}.jpg",
        })

    audio = analyze_audio(video, outdir, [s["end"] for s in sc_out[:-1]]) if info["has_audio"] else None
    profile = {
        "name": name, "source": str(video), **info,
        "color": color_stats(sample), "audio": audio, "scenes": sc_out,
        "summary": {
            "scene_count": len(sc_out),
            "avg_scene_len": round(float(np.mean([s["duration"] for s in sc_out])), 2),
            "motions": {k: sum(1 for s in sc_out if s["motion"]["label"] == k)
                        for k in ("zoom_in", "zoom_out", "pan", "static")},
        },
    }
    (outdir / "profile.json").write_text(json.dumps(profile, ensure_ascii=False, indent=2))
    print(json.dumps(profile["summary"], ensure_ascii=False, indent=2))
    print("color:", profile["color"])
    if audio:
        print(f"bpm={audio['bpm']} cuts_on_beat={audio['cuts_on_beat_ratio']}")
    print(f"-> {outdir}/profile.json  (حالا frames/ را ببین و STYLE.md را بنویس)")


if __name__ == "__main__":
    main()
