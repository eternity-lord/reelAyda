import json
import subprocess
import cv2
import numpy as np


def sh(cmd, quiet=True):
    r = subprocess.run([str(c) for c in cmd], capture_output=quiet, text=True)
    if r.returncode != 0:
        tail = (r.stderr or "")[-2000:]
        raise RuntimeError(f"command failed: {' '.join(map(str, cmd))}\n{tail}")
    return r


def probe(path):
    out = subprocess.check_output([
        "ffprobe", "-v", "error",
        "-show_entries", "stream=codec_type,width,height,r_frame_rate:format=duration",
        "-of", "json", str(path)])
    j = json.loads(out)
    v = next(s for s in j["streams"] if s["codec_type"] == "video")
    n, d = v["r_frame_rate"].split("/")
    return {
        "width": int(v["width"]), "height": int(v["height"]),
        "fps": float(n) / float(d) if float(d) else 30.0,
        "duration": float(j["format"]["duration"]),
        "has_audio": any(s["codec_type"] == "audio" for s in j["streams"]),
    }


def frame_at(cap, t):
    cap.set(cv2.CAP_PROP_POS_MSEC, max(t, 0) * 1000)
    ok, f = cap.read()
    return f if ok else None


def small(f, w=540):
    h = max(2, int(f.shape[0] * w / f.shape[1]))
    return cv2.resize(f, (w, h))


def color_stats(frames):
    sat, val, con, warm = [], [], [], []
    for f in frames:
        f = small(f, 320)
        hsv = cv2.cvtColor(f, cv2.COLOR_BGR2HSV)
        sat.append(float(hsv[..., 1].mean()))
        val.append(float(hsv[..., 2].mean()))
        con.append(float(cv2.cvtColor(f, cv2.COLOR_BGR2GRAY).std()))
        warm.append(float(f[..., 2].mean() - f[..., 0].mean()))
    m = lambda a: round(float(np.mean(a)), 2) if a else 0.0
    return {"saturation": m(sat), "brightness": m(val), "contrast": m(con), "warmth": m(warm)}
