# ayda-reel-agent

پایپ‌لاین تدوین خودکار ریلز برای پیج **ayda.nailroom**.

## کار شما (صاحب پیج)
1. فیلم مرجع را بگذار در `references/` (مثلاً `references/ref-01.mp4`) و push کن.
2. برای هر پست یک پوشه بساز: `inputs/post-01/` و عکس/فیلم‌ها را با نام‌های `01.jpg`, `02.mp4`, ... داخلش بگذار (اختیاری: `manifest.yaml`، نمونه در `inputs/_example`). push کن.
3. به ایجنت بگو: «`AGENTS.md` را بخوان و پست‌های جدید را تدوین کن.»
4. ایجنت: تحلیل مرجع → تدوین → کنترل کیفیت → کپشن → commit/push به `outputs/`.

## نیازمندی‌ها
`ffmpeg`، `python3.10+`، `git`، `git-lfs`؛ بعد `bash scripts/setup.sh`.

## دستی
```bash
source .venv/bin/activate
python tools/analyze_reference.py references/ref-01.mp4
python tools/build_edit.py --profile profiles/ref-01/profile.json --inputs inputs/post-01 --out outputs/post-01.mp4
python tools/qa_check.py outputs/post-01.mp4
bash scripts/publish.sh post-01
```

## نکته‌ها
- حجم: فایل‌های ویدیو/عکس با Git LFS ذخیره می‌شوند (سهمیه‌ی رایگان GitHub محدود است؛ مرجع‌ها و خام‌ها را کوتاه/فشرده نگه دار).
- آهنگ مرجع ممکن است کپی‌رایت داشته باشد؛ برای انتشار می‌توانی `--audio none` بگیری و آهنگ را در خود اینستاگرام بگذاری.
